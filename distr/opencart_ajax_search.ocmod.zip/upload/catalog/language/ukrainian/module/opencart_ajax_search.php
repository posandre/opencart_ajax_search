<?php
// Titles
$_['title_categories']          = 'Шукати в категоріях';
$_['title_products']            = 'Продукти';
$_['title_information']         = 'Сторінки';
$_['title_news']                = 'Новини';

// Text
$_['text_category_search']      = 'Шукати "%s" в категорії %s';
$_['text_empty_results']        = 'Нічого не знайдено. Спробуйте змінити запит.';