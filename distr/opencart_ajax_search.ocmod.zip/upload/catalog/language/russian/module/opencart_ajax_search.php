<?php
// Titles
$_['title_categories']          = 'Искать в категориях';
$_['title_products']            = 'Продукты';
$_['title_information']         = 'Страницы';
$_['title_news']                = 'Новини';

// Text
$_['text_category_search']      = 'Искать "%s" в категории "%s"';
$_['text_empty_results']        = 'Ничего не найдено. Попытайтесь изменить запрос.';