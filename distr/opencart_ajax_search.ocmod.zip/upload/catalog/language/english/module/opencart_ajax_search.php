<?php
// Titles
$_['title_categories']          = 'Search in categories';
$_['title_products']            = 'Products';
$_['title_information']         = 'Pages';
$_['title_news']                = 'News';


// Text
$_['text_category_search']      = 'Search "%s% in category %s';
$_['text_empty_results']        = 'Nothing found. Try changing the query.';